// File Name: Checkpoint 4
// Name: Dillon Teakell
//
// Date: 09-24-23
// Desc: Function that returns the sqaure root of a number from 1 - 10,000
import Foundation


enum SquareRootError: Error {
    case outOfBounds
    case noRationalRoot
}

func getSquareRoot(of number: Int) throws -> Int {
    // Base case - if 'number' is < 1 or > 10,000
    if number < 1 || number > 10_000 {
        throw SquareRootError.outOfBounds
    }
    // If 'number' is 1, then there is no root.
    if number == 1 {
        throw SquareRootError.noRationalRoot
    }
    
    // If i * i = number, then it's the sqaure root
    for i in 1...number {
        if i * i == number {
            return i
        }
    }
    throw SquareRootError.noRationalRoot
}


// Error Handling
let number = 25
    
do {
    let root = try getSquareRoot(of: number)
    print("The square root of \(number) is: \(root)")
}

catch SquareRootError.outOfBounds {
    print("Error: Integer provided is out of bounds")
    }

catch SquareRootError.noRationalRoot {
        print("Error: Integer has no rational root")
    }

catch {
        print("There was a problem")
    }
