// File Name: Checkpoint-9
// Name: Dillon Teakell
// Date: 10-3-23
//
// Desc: Checkpoint 9 - Optional Array of Integers

import UIKit

let array: [Int?] = []

func returnOneInteger(array: [Int?]) -> Int? {
    return array.randomElement() ?? Int.random(in: 1...100)
}

returnOneInteger(array: array)
