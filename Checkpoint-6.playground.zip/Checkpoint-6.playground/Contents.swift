// File Name: Checkpoint-6
// Name: Dillon Teakell
// Date:  09-28-23
//
// Desc: Checkpoint 6 - Create a struct of a Car


import UIKit

enum GearError: Error {
    case invalidGearAmountError
    case gearLimitError
}

struct Car {
    let manufacturer: String
    let model: String
    let numberOfSeats: Int
    var numberOfGears: Int
    private var currentGear: Int {
        didSet {
            print("Gear has been shifted (to gear: \(currentGear))")
        }
    }
    
    init(manufacturer: String, model: String, numberOfSeats: Int, numberOfGears: Int, currentGear: Int) {
        self.manufacturer = manufacturer
        self.model = model
        self.numberOfSeats = numberOfSeats
        self.numberOfGears = numberOfGears
        self.currentGear = currentGear
    }
    
    func showInfo() {
        print("Manufacturer: \(manufacturer)")
        print("Model: \(model)")
        print("Number of Seats: \(numberOfSeats)")
        print("Number of Gears: \(numberOfGears)")
        if currentGear == 0 {
            print("Current Gear: N \n")
        }
    }
    
    mutating func shiftGears(direction: String, gears: Int) throws {
        if direction == "up" {
           currentGear = currentGear + gears
            if currentGear > numberOfGears {
                throw GearError.gearLimitError
            }
        }
        
        else if direction == "down" {
            currentGear = currentGear - gears
            if currentGear < numberOfGears {
                throw GearError.gearLimitError
            }
        }
    }
    
    
    // Mock Data
    static let example = Car(manufacturer: "Suzuki", model: "Swift", numberOfSeats: 4, numberOfGears: 6, currentGear: 0)
}

var exampleCar = Car.example
exampleCar.showInfo()

do {
    try exampleCar.shiftGears(direction: "up", gears: 1)
}
catch GearError.invalidGearAmountError {
    print("Error: Amount of gears exceeds or subceeds usable amount")
}
catch GearError.gearLimitError {
    print("Error: Shift could not be completed - gear limit reached")
}

