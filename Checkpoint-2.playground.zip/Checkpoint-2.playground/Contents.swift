// File Name: Checkpoint-2
// Name: Dillon Teakell
//
// Date: 09-19-23
// Desc: Checkpoint 2 - Finding the amount of items in an array

import UIKit

let devices = ["iPhone", "iPad", "MacBook", "iMac", "Apple Watch"]

print("The number of items: \(devices.count)")

var devicesSet = Set(devices)

print("The number of unique items: \(devicesSet.count)")
