import UIKit

protocol Building {
    var numberOfRooms: Int { get }
    var cost: Int { get }
    var agentName: String { get }
    
    func getSummary()
}

struct House: Building {
    var numberOfRooms: Int
    var cost: Int
    var agentName: String
    
    func getSummary() {
        print("House Summary\n")
        print("Number of Rooms: \(numberOfRooms)")
        print("Cost: \(cost)")
        print("Agent Name: \(agentName)\n")
    }
}

struct Office: Building {
    var numberOfRooms: Int
    var cost: Int
    var agentName: String
    
    func getSummary() {
        print("Office Summary\n")
        print("Number of Rooms: \(numberOfRooms)")
        print("Cost: \(cost)")
        print("Agent Name: \(agentName)\n")
    }
}

var house = House(numberOfRooms: 4, cost: 367_000, agentName: "Dillon Teakell")
house.getSummary()

var office = Office(numberOfRooms: 60, cost: 1_000_000, agentName: "Dillon Teakell")
office.getSummary()
