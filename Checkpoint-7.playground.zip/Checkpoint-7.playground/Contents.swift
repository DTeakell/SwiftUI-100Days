// File Name: Checkpoint-7
// Name: Dillon Teakell
// Date: 10-2-23
//
// Desc: Creating classes and subclasses based on specific conditions

import UIKit

class Animal {
    var numberOfLegs: Int
    
    init(numberOfLegs: Int) {
        self.numberOfLegs = numberOfLegs
    }
}

class Dog: Animal {
    
    func speak() -> String {
        return "Bark!"
    }
    
    class Corgi: Dog {
        override func speak() -> String {
            return "Bark, bark, bark!"
        }
    }

    class Poodle: Dog {
        override func speak() -> String {
            return "Bark, bark!"
        }
    }
}

class Cat: Animal {
    
    var isTame: Bool
    
    init(numberOfLegs: Int, isTame: Bool) {
        self.isTame = isTame
        super.init(numberOfLegs: numberOfLegs)
    }
    
    func speak() -> String {
        return "Meow..."
    }
    
        class Persian: Cat {
            override func speak() -> String {
                return "meow..."
            }
        }
    
        class Lion: Cat {
            override func speak() -> String {
                return "ROAR!!"
            }
        }
    
}

var myDog = Dog.Corgi(numberOfLegs: 4)
myDog.speak()

var myCat = Cat.Lion(numberOfLegs: 4, isTame: true)
myCat.speak()
