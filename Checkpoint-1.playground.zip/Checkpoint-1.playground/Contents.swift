// File Name: Checkpoint-1
// Name: Dillon Teakell
//
// Date: 09-17-23
// Desc: Checkpoint 1 - Converting Celsius to Farenheit

import UIKit

let tempInCelsius = 32.0

let tempInFarenheit = (tempInCelsius * 9.0) / 5.0 + 32.0

let endMessage = """
Celsius Temperature: \(Int(tempInCelsius))°C
Farenheit Temperature: \(tempInFarenheit)°F
"""

print(endMessage)
