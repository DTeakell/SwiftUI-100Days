// File Name: Checkpoint-3
// Name: Dillon Teakell
//
// Date: 09-19-23
// Desc: Checkpoint 3 - FIZZBUZZ


import UIKit

for i in 1...100 {
    // If 'i' is divisible by both 3 and 5
    if i % 15 == 0 {
        print("\(i) - FIZZBUZZ!")
    }
    
    // If 'i' is divisible by 3
    else if i % 3 == 0 {
        print("\(i) - FIZZ")
    }
    
    // If 'i' is divisible by 5
    else if i % 5 == 0 {
        print("\(i) - BUZZ")
    }
    
    // If 'i' isn't divisible by anything
    else {
        print("\(i) - ...")
    }
}
